package com.example.laravelproject;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class PemenangResult {

    private List<Pemenang> winner;

    public List<Pemenang> getWinner() {
        return winner;
    }
}
